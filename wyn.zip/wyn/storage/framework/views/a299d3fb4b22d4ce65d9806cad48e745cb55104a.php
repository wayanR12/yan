<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\xamppnew\htdocs\larashop-laravel-8-master\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>