<?php echo e($slot); ?>

<?php /**PATH C:\xamppnew\htdocs\larashop-laravel-8-master\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>